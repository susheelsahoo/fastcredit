
<?php

if(!empty($_POST["contact_email"])) {
	$name 		= $_POST["contact_name"];
	$email 		= $_POST["contact_email"];
	$phone 		= $_POST["contact_phone"];
	$subject 	= $_POST["contact_subject"];
	$msg 		= $_POST["contact_message"];

	$msg  = "Name : ". $name  . "  phone : " .$phone  . "  subject : " .$subject  . "  message : " .$msg;
	
	$toEmail = "info@bhargavienterprises.co.in";
	$mailHeaders = "From: " . $name . "<". $email .">\r\n";
	if(mail($toEmail, 'Bhargavi Enterprise Query', $msg, $mailHeaders)) {
	    $message = "Your information is received successfully.";
	    $type = "success";
	}else{
        $message = "Something went wrong. Try again";
	    $type = "error";
    }
   // echo $message;
    header('Location: contacts.php?msg='.$message.'&type='.$type);
}

?>